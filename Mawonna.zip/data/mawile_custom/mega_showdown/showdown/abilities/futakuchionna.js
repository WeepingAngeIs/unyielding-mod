({
  onStart(pokemon) {
    let activated = false;
    for (const target of pokemon.foes()) {
      if (!activated) {
        this.add("-ability", pokemon, "Futakuchi-onna", "boost");
        activated = true;
      }
      if (target.volatiles["substitute"]) {
        this.add("-immune", target);
      } else {
        this.boost({ atk: -2, spa: -2 }, target, pokemon, null, true);
      }
    }
  },
  flags: {},
  name: "Futakuchi-onna",
  rating: 4,
  num: -9303
})
