MAWONNA V17 - FLORAL KIMONO
For the existing Cobblemon 1.8.2 / Minecraft 1.21.1 setup.
Species ID remains mawile_custom:mawile_third_evolution.

WHAT CHANGED
The fitted torso has a rounded warm neck, a gold-edged crossing neckline and
charcoal wrap panels. Lowered arms lead into hollow hanging sleeves with gold
lining, edging and blossom details. Simple hands rest together in front.
A broad gold obi has a dark center band, front cord knot and tassels. The rear
bow has modeled folded wings and hanging tails. A narrower dark skirt combines
overlapping cloth gores, selected gold panels and varied blossom clusters.
Gold flowers are thin modeled pixel details using existing opaque texture
swatches. They are real exported cubes, not a separate concept painting.

PRESERVED
All 71 protected head/face/hair/tendril/rope/maw bone definitions are unchanged.
The six small jaws, giant rear jaw, teeth, stem attachment, original straight
hair and face identity remain. No original texture pixels or UV locations were
repainted or moved. Hair and maw keep their original palette and construction.
Species stats, female-only status, ability, typing, IDs and gameplay are unchanged.
Source backup: the original v16 ZIP remains untouched in outputs and the installed
resourcepacks folder. An untouched extracted source also remains in v17/base.

RIG CHANGES
Existing body, head, hair, jaw and arm controls retain their names and pivots.
Old outfit cubes were replaced; empty legacy dress controls remain for editing.
New kimono_* bones hold the wrap, lapels, sash, bow, 16 skirt gores and sleeve
drapes. Old sleeve_bell_left/right were removed; no animation references them.
Sleeves and bow tails receive restrained follow-through. All skirt gores share
one synchronized rotation, maintaining their overlap instead of fanning apart.

ANIMATIONS CONNECTED TO EXISTING RUNTIME HOOKS
ground_idle: 6-second calm loop, soft breathing and relaxed hair.
battle_idle: 4-second smooth loop without the old jaw-opening endpoint spike.
walk: 1.3-second short alternating steps, coordinated hands and restrained cloth.
attack: 1.15-second rear-maw anticipation, snap and recovery.
chomp: 0.95-second quick bite for existing bite/crunch hooks.
hurt: 0.48-second brief recoil and recovery.
faint: 1.9-second slump followed by exactly 3 seconds holding the final pose.
cry: 2.4-second deliberate threatening jaw display using the existing cry hook.
sleep: existing rest adapted for the longer sleeves, skirt and bow.
recoil_ball: existing recall retained with calmer hair tips for sleeve clearance.
tendrils_a/b: quieter secondary motion with eased loop boundaries.
blink: existing eyelid geometry and existing hook retained.
The original poser is unchanged, including primary action overrides, static
battle-facing transform and the 1.12 jaw scale. No attack damage or range changed.

The inherited editor-only clips battle_entry, battle_exit, blink_slow,
idle_glance_left/right, idle_quirk_jaw/peek, jaw_test, rope_flex_demo and sit are
retained but are NOT connected by this pack's poser. Their presence is not a
claim that the game uses them. They are not part of the active-state checks.

CHECKS AND LIMITS
All pack JSON parses, bone parents precede their children, animation/poser names
resolve and new clothing UVs are supported integer box UVs with opaque pixels.
Protected geometry and gameplay/texture files were compared with the source.
Sampled local checks cover floor clearance, loop endpoints, the 3-second faint
hold, stem connection, and new outfit intersections with protected creature parts.
Reports are in VALIDATION.json and BUILD-REPORT.json. Deliberate fabric overlaps
and the original protected geometry are retained; these are not universal
collision-free or performance claims.
Real asset renders show front, rear, side and three-quarter views. The separate
outfit detail hides the maw/tendrils only for visibility of clothing; the actual
model includes them. Before/after renders use the same camera bounds and scale.
Idle preview covers a full shared cycle of the base and appendage loops. The
walking preview shows the main movement loop with the appendage overlay held at
its starting pose, so its repeat clearly shows the walking seam. In game the
appendage loops play independently. Action GIFs repeat short action excerpts.
NOT TESTED INSIDE MINECRAFT. Runtime blending, walking speed/skating and performance
still need checking in your game. No game files were installed by this build.

EDIT IN BLOCKBENCH
Open Mawonna-v17.bbmodel directly. The texture is embedded and clips are editable.
The companion runtime ZIP contains the external texture and Bedrock JSON assets.
As in the earlier editable versions, the runtime 1.12 jaw scale is baked into the
BB preview. Do not apply that scale a second time when exporting changes back.
Runtime supports box UV cubes; do not substitute unsupported per-face UV exports.

TEST IN YOUR EXISTING CURSEFORGE INSTANCE
Instance: C:/Users/tolov/curseforge/minecraft/Instances/Cobblemon Unyielding
1. Keep a backup of Mawonna-v16-V11-Joined-Hands.zip.
2. Put Mawonna-v17-Floral-Kimono.zip in that instance's resourcepacks folder.
3. Enable v17 in Minecraft Resource Packs and disable the old Mawonna resource
   pack so only one version provides the model. Restart Minecraft for testing.
4. If Mawonna already spawns in your setup, its existing data needs no changes.
   This is a visual update and the packaged species/ability data is identical.
   For a fresh local setup only, the same ZIP is also a data pack: put it in the
   target world's datapacks folder (your local world is saves/New World).
   Do not install duplicate copies of the Mawonna data alongside an existing one.
5. Test idle, walk, battle bite, damage, sleep, recall and faint. The final faint
   pose should remain held for 3 seconds after its 1.9-second slump.
Spawn ID if commands are available: mawile_custom:mawile_third_evolution

ASSET REPLACEMENTS IN THIS ZIP
assets/mawile_custom/bedrock/pokemon/models/mawile_third_evolution/mawile_third_evolution.geo.json
assets/mawile_custom/bedrock/pokemon/animations/mawile_third_evolution/mawile_third_evolution.animation.json
Updated pack.png, pack.mcmeta and reports. Texture, poser, resolver, language,
species, ability, inherited license and rope-editing notes are otherwise retained.
This is a Cobblemon addon/resource pack, not a Figura avatar.
