MAWONNA V16 - V11 MODEL / LONGER RESTING HANDS
For Cobblemon 1.8.2 / Minecraft 1.21.1.

Original v11 body, chest, hair, jaws and sleeve fabric restored.
The small yellow hands are replaced by longer charcoal wrists and palms with
two tapered fingers and a short thumb. One hand rests over the other in front
of the body. The wrists remain recessed into the existing sleeve openings.
Both arms move together during walking, keeping the hands in contact.

All other latest motions are preserved: walking legs, attack foot correction,
donor hair/jaw animation, and three extra seconds holding the final faint pose.
Latest female-only status, ability, stats and gameplay data are retained.
Species ID: mawile_custom:mawile_third_evolution
The v12-v15 torso, chest and neck redesigns are not part of this v11-based model.

Local checks verify hand contact without hand/hand penetration, clearance from
sleeve fabric and body, loop continuity, unchanged assets and floor clearance.
The original v11 hair already overlaps some upper-sleeve/shoulder geometry;
this is not a claim that all inherited geometry is free of intersections.
Not tested inside Minecraft. This build was not installed automatically.

INSTALL: Back up the current Mawonna version. Replace its ZIP in both
resourcepacks/ and saves/New World/datapacks/, enable the new resource pack,
and restart Minecraft. Enable only one Mawonna resource pack.
Spawn: /pokespawn mawile_custom:mawile_third_evolution

The companion bbmodel is an editable preview with the runtime 1.12 jaw scale
already baked in. Do not apply it twice when converting back to game files.
